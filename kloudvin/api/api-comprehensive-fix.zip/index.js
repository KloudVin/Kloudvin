const mammoth = require('mammoth');
const { BlobServiceClient } = require('@azure/storage-blob');

module.exports = async function (context, req) {
    context.log('DOCX conversion request received');

    try {
        const connectionString = process.env.AZURE_STORAGE_CONNECTION_STRING;
        if (!connectionString) {
            throw new Error('Storage connection string not configured');
        }

        const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
        const containerClient = blobServiceClient.getContainerClient('images');

        // Get DOCX file from request body
        if (!req.body || !req.body.docx) {
            throw new Error('No DOCX data provided');
        }

        const docxBuffer = Buffer.from(req.body.docx, 'base64');
        context.log('DOCX buffer size:', docxBuffer.length);

        // Convert DOCX to Markdown with image extraction
        const result = await mammoth.convertToMarkdown(docxBuffer, {
            styleMap: [
                "p[style-name='Heading 1'] => # ",
                "p[style-name='Heading 2'] => ## ",
                "p[style-name='Heading 3'] => ### ",
                "p[style-name='Heading 4'] => #### ",
                "p[style-name='Heading 5'] => ##### ",
                "p[style-name='Heading 6'] => ###### ",
                "p[style-name='Title'] => # ",
                "p[style-name='Subtitle'] => ## ",
                "p[style-name='heading 1'] => # ",
                "p[style-name='heading 2'] => ## ",
                "p[style-name='heading 3'] => ### ",
                "p[style-name='heading 4'] => #### ",
                "b => **",
                "i => *",
                "u => **",  // Underline treated as bold
                "code => `",
                "strike => ~~"
            ],
            preserveEmptyParagraphs: false,
            ignoreEmptyParagraphs: true,
            convertImage: mammoth.images.imgElement(async function(image) {
                try {
                    context.log('Processing image:', image.contentType);
                    const imageBuffer = await image.read();
                    context.log('Image buffer size:', imageBuffer.length);

                    // Generate unique filename
                    const extension = image.contentType.split('/')[1] || 'png';
                    const timestamp = Date.now();
                    const random = Math.random().toString(36).substring(7);
                    const filename = `${timestamp}-${random}.${extension}`;

                    context.log('Uploading image:', filename);

                    // Upload to blob storage
                    const blockBlobClient = containerClient.getBlockBlobClient(filename);
                    await blockBlobClient.upload(imageBuffer, imageBuffer.length, {
                        blobHTTPHeaders: { blobContentType: image.contentType }
                    });

                    context.log('Image uploaded:', blockBlobClient.url);

                    // Return image URL for markdown
                    return { src: blockBlobClient.url };
                } catch (imgError) {
                    context.log.error('Image extraction error:', imgError.message);
                    context.log.error('Stack:', imgError.stack);
                    return { src: '' };
                }
            })
        });

        context.log('Mammoth conversion complete, messages:', result.messages.length);

        // Clean up the markdown
        let markdown = result.value;

        // STEP 1: Remove escaped characters and TOC
        markdown = markdown
            // Remove backslash escapes
            .replace(/\\([().\[\]{}*_#+-])/g, '$1')

            // Remove table of contents completely
            .replace(/^#{1,3}\s*Contents\s*$/gmi, '')
            .replace(/^Contents\s*$/gmi, '')
            .replace(/^#{1,3}\s*Table\s+of\s+Contents\s*$/gmi, '')

            // Remove all TOC links and entries
            .replace(/\[__[^\]]*__\s*\d*\]\(#[^)]*\)/g, '')
            .replace(/\[[^\]]*\]\(#_Toc\d+\)/g, '')
            .replace(/\[[^\]]*\]\(#_Hlk\d+\)/g, '')
            .replace(/\[#_Toc\d+\]/g, '')

            // Remove TOC dotted lines
            .replace(/^\.{3,}.*$/gm, '')
            .replace(/^_{3,}.*$/gm, '')

            // Remove anchor tags
            .replace(/<a id="[^"]*"><\/a>/g, '')
            .replace(/<a id='[^']*'><\/a>/g, '')

            // Clean up headings - remove formatting
            .replace(/^(#{1,6})\s*__(.+?)__\s*$/gm, '$1 $2')
            .replace(/^(#{1,6})\s*\*\*(.+?)\*\*\s*$/gm, '$1 $2')

            // Convert __ to **
            .replace(/__/g, '**')

            // Remove bold from images
            .replace(/\*\*!\[/g, '![')
            .replace(/\]\([^)]+\)\*\*/g, (match) => match.replace(/\*\*$/, ''))

            // Remove page numbers
            .replace(/^\d+\s*$/gm, '')
            .replace(/^Page\s+\d+.*$/gmi, '')

            // Remove "read time" text
            .replace(/\d+\s*min\s*read/gi, '')

            // Clean up excess underscores
            .replace(/_{3,}/g, '')

            // Remove empty links
            .replace(/\[\]\([^)]*\)/g, '');

        // STEP 2: Extract title if present
        const lines = markdown.split('\n');
        let extractedTitle = '';
        let contentStartIndex = 0;
        let inTOC = false;

        // Look for title in first 10 lines
        for (let i = 0; i < Math.min(10, lines.length); i++) {
            const trimmed = lines[i].trim();

            if (trimmed === '') continue;

            // Check if this is TOC section
            if (trimmed.toLowerCase().includes('contents') || trimmed.toLowerCase().includes('table of contents')) {
                inTOC = true;
                continue;
            }

            // Skip TOC entries
            if (inTOC && (trimmed.match(/^\d+$/) || trimmed.match(/^\./))) {
                continue;
            }

            // End of TOC
            if (inTOC && trimmed.startsWith('#')) {
                inTOC = false;
            }

            // First substantial non-heading line might be title
            if (!trimmed.startsWith('#') && trimmed.length > 10 && trimmed.length < 100 && !extractedTitle && !inTOC) {
                // Check if this looks like a title (not a sentence with lots of words)
                const wordCount = trimmed.split(/\s+/).length;
                if (wordCount <= 10) {
                    extractedTitle = trimmed.replace(/\*\*/g, '');  // Remove bold
                    contentStartIndex = i + 1;
                    context.log('Extracted title:', extractedTitle);
                    break;
                }
            }

            // If we hit a heading, stop looking for title
            if (trimmed.startsWith('#')) {
                contentStartIndex = i;
                break;
            }
        }

        // STEP 3: Process lines for proper formatting
        const contentLines = lines.slice(contentStartIndex);
        const processedLines = [];
        let inList = false;
        let listType = '';
        let prevWasHeading = false;
        let skipTOC = false;

        for (let i = 0; i < contentLines.length; i++) {
            let line = contentLines[i].trimEnd();
            let trimmedLine = line.trim();

            // Skip empty lines strategically
            if (trimmedLine.length === 0) {
                if (inList) {
                    processedLines.push('');
                    inList = false;
                    listType = '';
                }
                if (prevWasHeading) {
                    processedLines.push('');
                    prevWasHeading = false;
                }
                continue;
            }

            // Skip TOC entries
            if (trimmedLine.toLowerCase().includes('contents') || skipTOC) {
                skipTOC = true;
                if (trimmedLine.startsWith('#')) {
                    skipTOC = false;
                } else {
                    continue;
                }
            }

            // Detect line types
            const isHeading = trimmedLine.match(/^(#{1,6})\s+(.+)/);
            const isNumbered = trimmedLine.match(/^(\s*)(\d+)\.\s+(.+)/);
            const isBullet = trimmedLine.match(/^(\s*)[-*•·●○]\s+(.+)/);
            const isCode = trimmedLine.match(/^```/);
            const isBold = trimmedLine.match(/^\*\*(.+)\*\*$/);

            // Code blocks
            if (isCode) {
                if (inList) {
                    processedLines.push('');
                    inList = false;
                }
                processedLines.push(trimmedLine);
                prevWasHeading = false;
                continue;
            }

            // Numbered lists with indentation
            if (isNumbered) {
                const [, indent, num, content] = isNumbered;
                const indentLevel = Math.floor(indent.length / 2);
                const indentStr = '  '.repeat(indentLevel);
                line = `${indentStr}${num}. ${content}`;

                if (!inList || listType !== 'numbered') {
                    if (processedLines.length > 0 && !prevWasHeading) processedLines.push('');
                    inList = true;
                    listType = 'numbered';
                }
                processedLines.push(line);
                prevWasHeading = false;
                continue;
            }

            // Bullet lists with indentation
            if (isBullet) {
                const [, indent, content] = isBullet;
                const indentLevel = Math.floor(indent.length / 2);
                const indentStr = '  '.repeat(indentLevel);
                line = `${indentStr}- ${content}`;

                if (!inList || listType !== 'bullet') {
                    if (processedLines.length > 0 && !prevWasHeading) processedLines.push('');
                    inList = true;
                    listType = 'bullet';
                }
                processedLines.push(line);
                prevWasHeading = false;
                continue;
            }

            // Headings
            if (isHeading) {
                const [, hashes, title] = isHeading;
                if (inList) {
                    processedLines.push('');
                    inList = false;
                }
                if (processedLines.length > 0 && !prevWasHeading) {
                    processedLines.push('');
                }
                processedLines.push(`${hashes} ${title.trim()}`);
                prevWasHeading = true;
                continue;
            }

            // Bold standalone lines (might be subheadings)
            if (isBold && trimmedLine.length < 80 && !trimmedLine.includes('.')) {
                if (inList) {
                    processedLines.push('');
                    inList = false;
                }
                if (processedLines.length > 0) processedLines.push('');
                processedLines.push(`### ${isBold[1]}`);
                prevWasHeading = true;
                continue;
            }

            // Regular text
            if (inList) {
                const prevLine = processedLines[processedLines.length - 1];
                if (prevLine && (prevLine.match(/^\s*\d+\./) || prevLine.match(/^\s*-/))) {
                    const prevIndent = prevLine.match(/^(\s*)/)[1];
                    processedLines.push(prevIndent + '  ' + trimmedLine);
                } else {
                    processedLines.push('');
                    inList = false;
                    processedLines.push(trimmedLine);
                }
            } else {
                processedLines.push(trimmedLine);
            }
            prevWasHeading = false;
        }

        // Final markdown
        markdown = processedLines.join('\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();

        context.log('Conversion successful');
        context.log('Markdown length:', markdown.length);
        context.log('Title extracted:', extractedTitle || 'none');
        context.log('Images found:', (markdown.match(/!\[/g) || []).length);

        context.res = {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
            body: {
                success: true,
                markdown: markdown,
                title: extractedTitle,  // Send extracted title to frontend
                messages: result.messages,
                imageCount: (markdown.match(/!\[/g) || []).length
            }
        };
    } catch (error) {
        context.log.error('Conversion error:', error.message);
        context.log.error('Stack:', error.stack);
        context.res = {
            status: 500,
            headers: { 'Content-Type': 'application/json' },
            body: {
                success: false,
                error: error.message
            }
        };
    }
};
